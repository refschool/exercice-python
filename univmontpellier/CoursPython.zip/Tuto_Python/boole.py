#Comparaison booléenne   George Boole (algèbre de boole)
2 > 2 # strictement
2 >= 2 # 2 plus grand ou égal à 1
2 <= 2
# égalité
2 == 2

#inégalité
2 != 1
# avec les chaines de caractère
"dupont" == "Dupont"

