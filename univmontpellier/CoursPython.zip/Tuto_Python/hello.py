print("hello")

"""
commentaire en python  triple guillemets ou apostrophe
-variable et les types
-if else
-boucle
-structure de données
-fonctions

"""