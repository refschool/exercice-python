'''structure de controle
IF ELSE (si ... sinon)


'''
age = 20
if(age > 18):
    print("vous êtes majeur")
else:
    print("Vous êtes mineur")

    

