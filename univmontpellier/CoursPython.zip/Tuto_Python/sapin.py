    *
   ***
  *****
 ******* 
    *
    *
    yvon.huynh@gmail.com
print("*" * 3) >> ***
for etoile in [1,3,5,7]:
