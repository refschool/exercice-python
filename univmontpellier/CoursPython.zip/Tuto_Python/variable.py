
""" variable
***NON!***
1nom 
nom prenom
nom?/
**OUI***
nom
nom1
nom_prenom
NomPrenom
"""
# variable =  valeur
nom = "Dupont"  # le type est une chaine de caractère
age = 48 # le type est un nombre
# une valeur a un type = nature de la valeur
age2 = "45"
message = "Bonjour"
print(message)

