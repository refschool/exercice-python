#while > for
"""
for i in [1,2,3]!
    print(i)


"""
liste = ["pierre","paul","jacques"]

#taille d'une liste
longueur = len(liste)

i = 0
while True:
    #imprimer
    print(i)
    i = i + 1 
